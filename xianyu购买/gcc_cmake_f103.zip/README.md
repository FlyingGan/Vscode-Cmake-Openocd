## 基于Cmake的stm32f103c6t6工程
搞定了调试配置(需要Jlink GDB参与)
写了编译任务以及Jlink下载任务