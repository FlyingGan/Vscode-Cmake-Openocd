#ifndef __MAIN_H
#define __MAIN_H
#include "stm32f4xx.h"
#include "led.h"
#include "string.h"
#define led_port GPIOC
#define led_pin GPIO_Pin_13
#endif
