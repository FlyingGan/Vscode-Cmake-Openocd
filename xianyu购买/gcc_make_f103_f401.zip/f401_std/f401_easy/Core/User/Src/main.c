#include "stm32f4xx.h"
#include "main.h"
#include "delay.h"
#include "usart.h"
int main(void)
{
    LED_Init();
    delay_init(84);
    uart_init(115200);
    while (1)
    {
        GPIO_SetBits(led_port, led_pin);
        delay_ms(500);
        GPIO_ResetBits(led_port, led_pin);
        delay_ms(500);
    }
}
