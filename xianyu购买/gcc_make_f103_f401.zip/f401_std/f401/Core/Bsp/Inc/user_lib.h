#ifndef _USER_LIB_H
#define _USER_LIB_H
#include "stm32f4xx.h"
void spi_flash_init(void);
void test_write(void);
uint32_t get_cpu(void);
#endif
